import pygame
import random
import sys
import math
import json
import os

pygame.init()

BASE_WIDTH, BASE_HEIGHT = 800, 600
fullscreen = False

screen = None
canvas = pygame.Surface((BASE_WIDTH, BASE_HEIGHT))

def apply_display_mode():
    global screen
    if fullscreen:
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    else:
        screen = pygame.display.set_mode((BASE_WIDTH, BASE_HEIGHT))

apply_display_mode()
pygame.display.set_caption("Путешествие Лиссы в Кибер-мире")
clock = pygame.time.Clock()
font = pygame.font.Font(None, 36)
small_font = pygame.font.Font(None, 28)
title_font = pygame.font.Font(None, 72)

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
ORANGE = (255, 165, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
GRAY = (128, 128, 128)
DARK_GRAY = (50, 50, 50)
CYAN = (0, 255, 255)
PURPLE = (255, 0, 255)
BLUE = (0, 0, 255)
ORANGE_ENEMY = (255, 140, 0)

STATE_SAVE_SELECT = "save_select"
STATE_MENU = "menu"
STATE_SETTINGS = "settings"
STATE_AUDIO_SETTINGS = "audio_settings"
STATE_AUTOMATION_SETTINGS = "automation_settings"
STATE_AUTO_UPGRADE_SETTINGS = "auto_upgrade_settings"
STATE_AUTO_IMPLANT_SETTINGS = "auto_implant_settings"
STATE_PLAYING = "playing"
STATE_GAME_OVER = "game_over"
STATE_WORKSHOP = "workshop"
STATE_IMPLANTS = "implants"
STATE_CHECKPOINTS = "checkpoints"

state = STATE_SAVE_SELECT

SAVE_FILES = ["save1.json", "save2.json", "save3.json"]
current_save_slot = None
selected_save_index = 0

total_patches = 0
last_earned_patches = 0
patches_earned = False

upgrade_levels = {
    "hp": 0,
    "damage": 0,
    "speed": 0,
    "firerate": 0,
    "xp_gain": 0,
    "regen": 0,
    "level_fast": 0,
    "level_slow": 0,
    "enemy_speed": 0,
    "item_spawn": 0
}

implants = {
    "bomb": {"owned": False, "cost": 50,  "key": pygame.K_1, "cooldown": 600, "duration": 0,  "name": "Бомба"},
    "data": {"owned": False, "cost": 100, "key": pygame.K_2, "cooldown": 1800, "duration": 600, "name": "Сбор данных"},
    "vanish": {"owned": False, "cost": 100, "key": pygame.K_3, "cooldown": 1800, "duration": 600, "name": "Исчезновение"},
    "absolute": {"owned": False, "cost": 150, "key": pygame.K_4, "cooldown": 3600, "duration": 600, "name": "Абсолютная форма"},
    "thanos": {"owned": False, "cost": 200, "key": pygame.K_5, "cooldown": 1200, "duration": 0, "name": "Щелчок Таноса"}
}

max_boss_defeated = 0

# Звуки и музыка
try:
    menu_music = "меню.ogg"
    battle_music = "бой.ogg"
    sound_purchase = pygame.mixer.Sound("покупка.ogg")
    sound_shoot = pygame.mixer.Sound("выстрел.ogg")
    sound_start = pygame.mixer.Sound("новая игра.ogg")
    sound_boss_win = pygame.mixer.Sound("победа.ogg")
    sound_death = pygame.mixer.Sound("смерть.ogg")
    sound_xp = pygame.mixer.Sound("XP.ogg")
    sounds_loaded = True
except:
    sounds_loaded = False

implant_sounds = {}
try:
    implant_sounds["bomb"] = pygame.mixer.Sound("бомба.ogg")
except:
    implant_sounds["bomb"] = None
try:
    implant_sounds["data"] = pygame.mixer.Sound("сбор данных.ogg")
except:
    implant_sounds["data"] = None
try:
    implant_sounds["vanish"] = pygame.mixer.Sound("исчезновение.ogg")
except:
    implant_sounds["vanish"] = None
try:
    implant_sounds["absolute"] = pygame.mixer.Sound("абсолютная форма.ogg")
except:
    implant_sounds["absolute"] = None
try:
    implant_sounds["thanos"] = pygame.mixer.Sound("щелчок таноса.ogg")
except:
    implant_sounds["thanos"] = None

# Настройки громкости (сохраняются)
music_volume = 100
sfx_volume = 100
shoot_sound_enabled = True
alternative_music = False

# Настройки автоматики
auto_attack = False
auto_upgrade = False
auto_implants = False
auto_walk = False
auto_walk_dir = 1

# Константы улучшений
UPGRADE_HP = "hp"
UPGRADE_DAMAGE = "damage"
UPGRADE_SPEED = "speed"
UPGRADE_FIRERATE = "firerate"
UPGRADE_XP = "xp_gain"
UPGRADE_REGEN = "regen"
UPGRADE_LEVEL_FAST = "level_fast"
UPGRADE_LEVEL_SLOW = "level_slow"
UPGRADE_ENEMY_SPEED = "enemy_speed"
UPGRADE_ITEM_SPAWN = "item_spawn"

ALL_UPGRADES = [
    UPGRADE_HP, UPGRADE_DAMAGE, UPGRADE_SPEED,
    UPGRADE_FIRERATE, UPGRADE_XP, UPGRADE_REGEN,
    UPGRADE_LEVEL_FAST, UPGRADE_LEVEL_SLOW,
    UPGRADE_ENEMY_SPEED, UPGRADE_ITEM_SPAWN
]

allowed_auto_upgrades = [UPGRADE_HP, UPGRADE_DAMAGE, UPGRADE_SPEED,
                         UPGRADE_FIRERATE, UPGRADE_XP, UPGRADE_REGEN,
                         UPGRADE_LEVEL_FAST, UPGRADE_LEVEL_SLOW,
                         UPGRADE_ENEMY_SPEED, UPGRADE_ITEM_SPAWN]
allowed_auto_implants = ["bomb", "data", "vanish", "absolute", "thanos"]

# --- Графические кнопки ---
BUTTON_SIZE = 60  # фиксированный размер для всех кнопок

def load_button_image(filename, size=BUTTON_SIZE):
    try:
        img = pygame.image.load(filename).convert_alpha()
        return pygame.transform.scale(img, (size, size))
    except:
        return None

# Кнопка стрельбы (нижний левый угол)
btn_shoot = load_button_image("стрельба.png", BUTTON_SIZE)
shoot_rect = pygame.Rect(20, BASE_HEIGHT - BUTTON_SIZE - 20, BUTTON_SIZE, BUTTON_SIZE)
touch_buttons = {"shoot": False}

# Кнопка приседа (правее стрельбы)
btn_crouch = load_button_image("присед.png", BUTTON_SIZE)
crouch_rect = pygame.Rect(shoot_rect.right + 10, BASE_HEIGHT - BUTTON_SIZE - 20, BUTTON_SIZE, BUTTON_SIZE)
touch_buttons["crouch"] = False

# Кнопка вправо (нижний правый угол)
btn_right = load_button_image("право.png", BUTTON_SIZE)
right_rect = pygame.Rect(BASE_WIDTH - BUTTON_SIZE - 20, BASE_HEIGHT - BUTTON_SIZE - 20, BUTTON_SIZE, BUTTON_SIZE)
touch_buttons["right"] = False

# Кнопка влево (левее кнопки вправо)
btn_left = load_button_image("лево.png", BUTTON_SIZE)
left_rect = pygame.Rect(right_rect.left - BUTTON_SIZE - 10, BASE_HEIGHT - BUTTON_SIZE - 20, BUTTON_SIZE, BUTTON_SIZE)
touch_buttons["left"] = False

# Кнопка паузы (верхний правый угол)
btn_pause = load_button_image("пауза.png", BUTTON_SIZE)
pause_rect = pygame.Rect(BASE_WIDTH - BUTTON_SIZE - 20, 20, BUTTON_SIZE, BUTTON_SIZE)
touch_buttons["pause"] = False

# Кнопки имплантов (1..5) вертикально под паузой с небольшим отступом
implant_buttons = {}
implant_rects = {}
y_offset = pause_rect.bottom + 10
for i, key in enumerate(["bomb", "data", "vanish", "absolute", "thanos"]):
    fname = f"кнопка{i+1}.png"
    img = load_button_image(fname, BUTTON_SIZE)
    implant_buttons[key] = img
    rect = pygame.Rect(BASE_WIDTH - BUTTON_SIZE - 20, y_offset + i * (BUTTON_SIZE + 5), BUTTON_SIZE, BUTTON_SIZE)
    implant_rects[key] = rect
    touch_buttons[key] = False

def apply_audio_settings():
    if not sounds_loaded:
        return
    pygame.mixer.music.set_volume(music_volume / 100.0)
    for s in [sound_purchase, sound_shoot, sound_start, sound_boss_win, sound_death, sound_xp]:
        s.set_volume(sfx_volume / 100.0)
    for s in implant_sounds.values():
        if s:
            s.set_volume(sfx_volume / 100.0)

current_music = None

def get_menu_music():
    if alternative_music and os.path.exists("меню2.ogg"):
        return "меню2.ogg"
    return "меню.ogg3"

def get_battle_music():
    if alternative_music and os.path.exists("бой2.ogg"):
        return "бой2.ogg"
    return "бой.ogg"

def set_music(track):
    global current_music
    if not sounds_loaded:
        return
    if current_music != track:
        pygame.mixer.music.stop()
        try:
            pygame.mixer.music.load(track)
            pygame.mixer.music.play(-1)
            current_music = track
        except:
            if track == get_menu_music() and alternative_music:
                pygame.mixer.music.load("меню.ogg")
                pygame.mixer.music.play(-1)
                current_music = "меню.ogg"
            elif track == get_battle_music() and alternative_music:
                pygame.mixer.music.load("бой.ogg")
                pygame.mixer.music.play(-1)
                current_music = "бой.ogg"

def save_game(slot_filename):
    data = {
        "total_patches": total_patches,
        "upgrade_levels": upgrade_levels,
        "implants": {k: v["owned"] for k, v in implants.items()},
        "max_boss_defeated": max_boss_defeated,
        "music_volume": music_volume,
        "sfx_volume": sfx_volume,
        "shoot_sound_enabled": shoot_sound_enabled,
        "alternative_music": alternative_music,
        "auto_attack": auto_attack,
        "auto_upgrade": auto_upgrade,
        "auto_implants": auto_implants,
        "auto_walk": auto_walk,
        "allowed_auto_upgrades": allowed_auto_upgrades,
        "allowed_auto_implants": allowed_auto_implants
    }
    with open(slot_filename, 'w') as f:
        json.dump(data, f)

def load_game(slot_filename):
    global total_patches, upgrade_levels, max_boss_defeated, music_volume, sfx_volume, shoot_sound_enabled
    global alternative_music
    global auto_attack, auto_upgrade, auto_implants, auto_walk
    global allowed_auto_upgrades, allowed_auto_implants
    with open(slot_filename, 'r') as f:
        data = json.load(f)
    total_patches = data["total_patches"]
    upgrade_levels = data["upgrade_levels"]
    for k, v in data["implants"].items():
        implants[k]["owned"] = v
    max_boss_defeated = data["max_boss_defeated"]
    music_volume = data.get("music_volume", 100)
    sfx_volume = data.get("sfx_volume", 100)
    shoot_sound_enabled = data.get("shoot_sound_enabled", True)
    alternative_music = data.get("alternative_music", False)
    auto_attack = data.get("auto_attack", False)
    auto_upgrade = data.get("auto_upgrade", False)
    auto_implants = data.get("auto_implants", False)
    auto_walk = data.get("auto_walk", False)
    allowed_auto_upgrades = data.get("allowed_auto_upgrades", [
        UPGRADE_HP, UPGRADE_DAMAGE, UPGRADE_SPEED,
        UPGRADE_FIRERATE, UPGRADE_XP, UPGRADE_REGEN,
        UPGRADE_LEVEL_FAST, UPGRADE_LEVEL_SLOW,
        UPGRADE_ENEMY_SPEED, UPGRADE_ITEM_SPAWN
    ])
    allowed_auto_implants = data.get("allowed_auto_implants", ["bomb", "data", "vanish", "absolute", "thanos"])
    apply_audio_settings()

score = 0
level = 1
level_interval = 300
level_timer = level_interval
base_enemy_speed = 3
enemy_speed_reduction = 0
enemy_spawn_rate = 40
item_spawn_delay = 60
frame_count = 0
paused = False
upgrade_menu = False
showing_stats = False
menu_selection = 0

settings_from_pause = False

player_width, player_height = 50, 30
player_x = BASE_WIDTH // 2 - player_width // 2
player_y = BASE_HEIGHT - player_height - 20
player_speed = 5
player_hp = 1
player_max_hp = 1
invincible_timer = 0

bullet_speed = 10
bullet_damage = 1
shoot_delay = 25
shoot_cooldown = 0

xp = 0
xp_to_next = 50
xp_bonus = 0
regen_timer = 0
regen_interval = 3600

enemies = []
bullets = []
items = []
bombs = []
explosions = []

boss = None
boss_number = 0
boss_active = False
boss_bullets = []

checkpoint_page = 0

BOSS_WIDTH, BOSS_HEIGHT = 120, 120
BOSS_START_Y = -150
BOSS_IDLE_Y = 50

upgrade_choices = []

# --- Функции игровой логики ---
def spawn_enemy():
    r = random.random()
    if level < 10:
        enemy_type = 'normal'
    elif level < 20:
        if r < 0.6:
            enemy_type = 'normal'
        elif r < 0.8:
            enemy_type = 'fast'
        else:
            enemy_type = 'heavy'
    elif level < 30:
        if r < 0.45:
            enemy_type = 'normal'
        elif r < 0.675:
            enemy_type = 'fast'
        elif r < 0.9:
            enemy_type = 'heavy'
        elif r < 0.925:
            enemy_type = 'shooter'
        else:
            enemy_type = 'exploder'
    else:
        if r < 0.25:
            enemy_type = 'normal'
        elif r < 0.5:
            enemy_type = 'fast'
        elif r < 0.75:
            enemy_type = 'heavy'
        elif r < 0.8:
            enemy_type = 'shooter'
        else:
            enemy_type = 'exploder'

    x = random.randint(0, BASE_WIDTH - 30)
    enemy_hp = 1 + max(0, (level - 1) // 5)
    speed = base_enemy_speed + level * 0.5

    if enemy_type == 'normal':
        enemies.append({
            'rect': pygame.Rect(x, -30, 30, 30),
            'hp': enemy_hp,
            'type': 'normal',
            'speed': speed
        })
    elif enemy_type == 'fast':
        enemies.append({
            'rect': pygame.Rect(x, -15, 20, 20),
            'hp': 1,
            'type': 'fast',
            'speed': speed * 2
        })
    elif enemy_type == 'heavy':
        enemies.append({
            'rect': pygame.Rect(x, -50, 50, 50),
            'hp': enemy_hp * 3,
            'type': 'heavy',
            'speed': max(1, speed * 0.5)
        })
    elif enemy_type == 'shooter':
        enemies.append({
            'rect': pygame.Rect(x, 50, 30, 30),
            'hp': enemy_hp,
            'type': 'shooter',
            'speed': 2,
            'shoot_timer': random.randint(60, 120),
            'dir': random.choice([-1, 1])
        })
    elif enemy_type == 'exploder':
        enemies.append({
            'rect': pygame.Rect(x, -35, 35, 35),
            'hp': enemy_hp,
            'type': 'exploder',
            'speed': speed
        })

def spawn_item():
    x = random.randint(0, BASE_WIDTH - 20)
    items.append(pygame.Rect(x, -20, 20, 20))

def spawn_bullet():
    dmg = bullet_damage
    if implants["absolute"].get('duration_timer', 0) > 0:
        dmg = max(bullet_damage, bullet_damage + 10)
    bullet_rect = pygame.Rect(
        player_x + player_width // 2 - 3,
        player_y,
        6, 12
    )
    bullets.append({
        'rect': bullet_rect,
        'damage': dmg
    })
    if sounds_loaded and shoot_sound_enabled:
        sound_shoot.play()

def apply_permanent_upgrades():
    for uid, lvl in upgrade_levels.items():
        for _ in range(lvl):
            apply_upgrade(uid)

def calculate_total_cost():
    total = 0
    for uid in ALL_UPGRADES:
        lvl = upgrade_levels[uid]
        for i in range(lvl):
            total += 5 + 5 * i
    return total

def reset_workshop_upgrades():
    global total_patches
    total_patches += calculate_total_cost()
    for uid in ALL_UPGRADES:
        upgrade_levels[uid] = 0
    global allowed_auto_upgrades
    allowed_auto_upgrades = [UPGRADE_HP, UPGRADE_DAMAGE, UPGRADE_SPEED,
                             UPGRADE_FIRERATE, UPGRADE_XP, UPGRADE_REGEN,
                             UPGRADE_LEVEL_FAST, UPGRADE_LEVEL_SLOW,
                             UPGRADE_ENEMY_SPEED, UPGRADE_ITEM_SPAWN]
    if current_save_slot:
        save_game(current_save_slot)

def reset_game():
    global score, level, level_interval, level_timer, enemies, bullets, items, bombs, explosions
    global frame_count, paused, upgrade_menu, showing_stats, shoot_cooldown
    global player_x, player_hp, player_max_hp, invincible_timer
    global xp, xp_to_next, xp_bonus, regen_timer, regen_interval
    global player_speed, bullet_damage, shoot_delay
    global base_enemy_speed, enemy_speed_reduction, item_spawn_delay
    global state, menu_selection
    global patches_earned, last_earned_patches
    global boss, boss_number, boss_active, boss_bullets

    score = 0
    level = 1
    level_interval = 300
    level_timer = level_interval
    base_enemy_speed = 3
    enemy_speed_reduction = 0
    enemy_spawn_rate = 40
    item_spawn_delay = 60
    enemies.clear()
    bullets.clear()
    items.clear()
    bombs.clear()
    explosions.clear()
    boss_bullets.clear()
    frame_count = 0
    paused = False
    upgrade_menu = False
    showing_stats = False
    shoot_cooldown = 0
    player_x = BASE_WIDTH // 2 - player_width // 2
    player_hp = 1
    player_max_hp = 1
    invincible_timer = 0
    xp = 0
    xp_to_next = 50
    xp_bonus = 0
    regen_timer = 0
    regen_interval = 3600
    player_speed = 5
    bullet_damage = 1
    shoot_delay = 25
    state = STATE_PLAYING
    menu_selection = 0
    patches_earned = False
    last_earned_patches = 0

    boss = None
    boss_number = 0
    boss_active = False

    for imp in implants.values():
        imp['timer'] = 0

    apply_permanent_upgrades()

    if sounds_loaded:
        sound_start.play()
    set_music(get_battle_music())

def generate_upgrade_choices():
    available = []
    for uid in ALL_UPGRADES:
        if uid == UPGRADE_REGEN and regen_interval <= 600:
            continue
        if uid == UPGRADE_LEVEL_FAST and level_interval <= 60:
            continue
        if uid == UPGRADE_FIRERATE and shoot_delay <= 3:
            continue
        if uid == UPGRADE_ITEM_SPAWN and item_spawn_delay <= 10:
            continue
        available.append(uid)
    return available

def apply_upgrade(upgrade_id):
    global player_max_hp, player_hp, bullet_damage, player_speed
    global shoot_delay, xp_bonus, regen_interval
    global level_interval, enemy_speed_reduction, item_spawn_delay

    if upgrade_id == UPGRADE_HP:
        player_max_hp += 1
        player_hp = min(player_hp + 1, player_max_hp)
    elif upgrade_id == UPGRADE_DAMAGE:
        bullet_damage += 1
    elif upgrade_id == UPGRADE_SPEED:
        player_speed += 1
    elif upgrade_id == UPGRADE_FIRERATE:
        shoot_delay = max(3, shoot_delay - 1)
    elif upgrade_id == UPGRADE_XP:
        xp_bonus += 1
    elif upgrade_id == UPGRADE_REGEN:
        regen_interval = max(600, regen_interval - 300)
    elif upgrade_id == UPGRADE_LEVEL_FAST:
        level_interval = max(60, level_interval - 30)
    elif upgrade_id == UPGRADE_LEVEL_SLOW:
        level_interval += 30
    elif upgrade_id == UPGRADE_ENEMY_SPEED:
        enemy_speed_reduction += 2
    elif upgrade_id == UPGRADE_ITEM_SPAWN:
        item_spawn_delay = max(10, item_spawn_delay - 5)

def spawn_boss():
    global boss, boss_active, boss_number, boss_bullets
    boss_number += 1
    boss_hp = level * 3
    boss = {
        'rect': pygame.Rect(BASE_WIDTH // 2 - BOSS_WIDTH // 2, BOSS_START_Y, BOSS_WIDTH, BOSS_HEIGHT),
        'hp': boss_hp,
        'max_hp': boss_hp,
        'speed_x': 2,
        'state': 'spawning',
        'timer': 0,
        'shoot_timer': 120,
        'summon_timer': 300,
        'rush_timer': 180,
        'rush_active': False,
        'rush_duration': 0,
        'rush_direction': 0,
        'rush_speed': 6,
        'charge_state': 0
    }
    boss_active = True
    boss_bullets.clear()

def start_game_from_checkpoint(boss_num):
    global score, level, level_interval, level_timer, enemies, bullets, items, bombs, explosions
    global frame_count, paused, upgrade_menu, showing_stats, shoot_cooldown
    global player_x, player_hp, player_max_hp, invincible_timer
    global xp, xp_to_next, xp_bonus, regen_timer, regen_interval
    global player_speed, bullet_damage, shoot_delay
    global base_enemy_speed, enemy_speed_reduction, item_spawn_delay
    global state, menu_selection
    global patches_earned, last_earned_patches
    global boss, boss_number, boss_active, boss_bullets

    score = 0
    level = boss_num * 30 + 1
    level_interval = 300
    level_timer = level_interval
    base_enemy_speed = 3
    enemy_speed_reduction = 0
    enemy_spawn_rate = 40
    item_spawn_delay = 60
    enemies.clear()
    bullets.clear()
    items.clear()
    bombs.clear()
    explosions.clear()
    boss_bullets.clear()
    frame_count = 0
    paused = False
    upgrade_menu = False
    showing_stats = False
    shoot_cooldown = 0
    player_x = BASE_WIDTH // 2 - player_width // 2
    player_hp = 1
    player_max_hp = 1
    invincible_timer = 0
    xp = 0
    xp_to_next = 50
    xp_bonus = 0
    regen_timer = 0
    regen_interval = 3600
    player_speed = 5
    bullet_damage = 1
    shoot_delay = 25
    state = STATE_PLAYING
    menu_selection = 0
    patches_earned = False
    last_earned_patches = 0

    boss_number = boss_num
    boss = None
    boss_active = False

    for imp in implants.values():
        imp['timer'] = 0

    apply_permanent_upgrades()

    if sounds_loaded:
        sound_start.play()
    set_music(get_battle_music())

def get_upgrade_description(upgrade_id):
    if upgrade_id == UPGRADE_HP:
        return f"Живучесть (+1 HP)        [HP: {player_max_hp}]"
    elif upgrade_id == UPGRADE_DAMAGE:
        return f"Урон (+1)                [урон: {bullet_damage}]"
    elif upgrade_id == UPGRADE_SPEED:
        return f"Скорость (+1)            [скор.: {player_speed}]"
    elif upgrade_id == UPGRADE_FIRERATE:
        return f"Скорострельность (-1 зад.)[зад.: {shoot_delay}]"
    elif upgrade_id == UPGRADE_XP:
        return f"Опыт (+1 за логин)       [бонус: {xp_bonus}]"
    elif upgrade_id == UPGRADE_REGEN:
        return f"Регенерация (+1 HP/мин)  [интерв.: {regen_interval//60}с]"
    elif upgrade_id == UPGRADE_LEVEL_FAST:
        return f"Ускорение уровней (-0.5с)[инт.: {level_interval/60:.1f}с]"
    elif upgrade_id == UPGRADE_LEVEL_SLOW:
        return f"Замедление уровней (+0.5с)[инт.: {level_interval/60:.1f}с]"
    elif upgrade_id == UPGRADE_ENEMY_SPEED:
        return f"Скорость багов (-2)      [замедл.: {enemy_speed_reduction}]"
    elif upgrade_id == UPGRADE_ITEM_SPAWN:
        return f"Спавн логинов (+1)       [интерв.: {item_spawn_delay}]"
    return "???"

def get_permanent_upgrade_info(upgrade_id):
    lvl = upgrade_levels[upgrade_id]
    max_reached = False
    if upgrade_id == UPGRADE_REGEN and lvl >= 10:
        max_reached = True
    elif upgrade_id == UPGRADE_LEVEL_FAST and lvl >= 9:
        max_reached = True
    elif upgrade_id == UPGRADE_FIRERATE and lvl >= 22:
        max_reached = True
    elif upgrade_id == UPGRADE_ITEM_SPAWN and lvl >= 10:
        max_reached = True

    if max_reached:
        descriptions = {
            UPGRADE_REGEN: f"Авто-восстановление (реген.)    [ур.MAX]",
            UPGRADE_LEVEL_FAST: f"Разгон системы (уровень чаще)   [ур.MAX]",
            UPGRADE_FIRERATE: f"Частота атаки (-1 задержка)   [ур.MAX]",
            UPGRADE_ITEM_SPAWN: f"Генератор пакетов (чаще спавн) [ур.MAX]"
        }
        return descriptions.get(upgrade_id, "MAX")
    else:
        cost = 5 + 5 * lvl
        descriptions = {
            UPGRADE_HP: f"Броня (+1 HP)                  [ур.{lvl}] - {cost} патчей",
            UPGRADE_DAMAGE: f"Мощность бластера (+1 урон)    [ур.{lvl}] - {cost} патчей",
            UPGRADE_SPEED: f"Ускорение (+1 скорость)         [ур.{lvl}] - {cost} патчей",
            UPGRADE_FIRERATE: f"Частота атаки (-1 задержка)   [ур.{lvl}] - {cost} патчей",
            UPGRADE_XP: f"Усилитель данных (+1 опыт)      [ур.{lvl}] - {cost} патчей",
            UPGRADE_REGEN: f"Авто-восстановление (реген.)    [ур.{lvl}] - {cost} патчей",
            UPGRADE_LEVEL_FAST: f"Разгон системы (уровень чаще)   [ур.{lvl}] - {cost} патчей",
            UPGRADE_LEVEL_SLOW: f"Стабилизатор (уровень реже)     [ур.{lvl}] - {cost} патчей",
            UPGRADE_ENEMY_SPEED: f"Торможение вирусов (-2 скор.)  [ур.{lvl}] - {cost} патчей",
            UPGRADE_ITEM_SPAWN: f"Генератор пакетов (чаще спавн) [ур.{lvl}] - {cost} патчей",
        }
        return descriptions.get(upgrade_id, "???")

# --- Функции отрисовки ---
def draw_save_select():
    canvas.fill(BLACK)
    title = title_font.render("Выберите сохранение", True, WHITE)
    title_rect = title.get_rect(center=(BASE_WIDTH//2, BASE_HEIGHT//2 - 140))
    canvas.blit(title, title_rect)

    for i, fname in enumerate(SAVE_FILES):
        exists = os.path.exists(fname)
        if exists:
            with open(fname, 'r') as f:
                data = json.load(f)
            info = f"Сохранение {i+1}  (Патчи: {data['total_patches']}, Боссы: {data['max_boss_defeated']})"
        else:
            info = f"Сохранение {i+1}  (пусто)"
        color = YELLOW if i == selected_save_index else WHITE
        text = font.render(info, True, color)
        rect = text.get_rect(center=(BASE_WIDTH//2, BASE_HEIGHT//2 - 50 + i*60))
        canvas.blit(text, rect)

    exit_color = YELLOW if selected_save_index == 3 else WHITE
    exit_text = font.render("Выйти из игры", True, exit_color)
    exit_rect = exit_text.get_rect(center=(BASE_WIDTH//2, BASE_HEIGHT//2 + 130))
    canvas.blit(exit_text, exit_rect)

    hint = font.render("Стрелки - выбор, Enter - загрузить, Shift+Enter - удалить", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH//2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_main_menu():
    canvas.fill(BLACK)
    title_text = title_font.render("Путешествие Лиссы", True, ORANGE)
    title_rect = title_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 200))
    canvas.blit(title_text, title_rect)
    subtitle_text = title_font.render("в Кибер-мире", True, ORANGE)
    subtitle_rect = subtitle_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 150))
    canvas.blit(subtitle_text, subtitle_rect)

    menu_items = ["Новая игра", "Сборочная станция", "Кибер-импланты", "Точки восстановления", "Настройки", "Выйти из игры"]
    for i, item in enumerate(menu_items):
        color = YELLOW if i == menu_selection else WHITE
        text = font.render(item, True, color)
        text_rect = text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 80 + i * 50))
        canvas.blit(text, text_rect)

    patches_text = font.render(f"Патчи: {total_patches}", True, YELLOW)
    canvas.blit(patches_text, (BASE_WIDTH - patches_text.get_width() - 20, 20))

    hint = font.render("Стрелки - выбор, Enter - подтвердить", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_settings_menu():
    canvas.fill(BLACK)
    title_text = font.render("Настройки", True, WHITE)
    title_rect = title_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 100))
    canvas.blit(title_text, title_rect)

    items = ["Полноэкранный режим: " + ("Вкл" if fullscreen else "Выкл"),
             "Музыка и звуки",
             "Автоматика",
             "Назад"]
    for i, item_text in enumerate(items):
        color = YELLOW if i == menu_selection else WHITE
        surf = font.render(item_text, True, color)
        rect = surf.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 40 + i * 50))
        canvas.blit(surf, rect)

    hint = font.render("Стрелки - выбор, Enter - изменить/перейти", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_audio_settings():
    canvas.fill(BLACK)
    title_text = font.render("Музыка и звуки", True, WHITE)
    title_rect = title_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 140))
    canvas.blit(title_text, title_rect)

    music_text = f"Музыка: {music_volume}  [← →]"
    color = YELLOW if menu_selection == 0 else WHITE
    surf = font.render(music_text, True, color)
    rect = surf.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 60))
    canvas.blit(surf, rect)

    sfx_text = f"Звуки: {sfx_volume}  [← →]"
    color = YELLOW if menu_selection == 1 else WHITE
    surf = font.render(sfx_text, True, color)
    rect = surf.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 20))
    canvas.blit(surf, rect)

    shoot_text = "Звук выстрелов: " + ("Вкл" if shoot_sound_enabled else "Выкл")
    color = YELLOW if menu_selection == 2 else WHITE
    surf = font.render(shoot_text, True, color)
    rect = surf.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 + 20))
    canvas.blit(surf, rect)

    alt_text = "Альтернативная музыка: " + ("Вкл" if alternative_music else "Выкл")
    color = YELLOW if menu_selection == 3 else WHITE
    surf = font.render(alt_text, True, color)
    rect = surf.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 + 60))
    canvas.blit(surf, rect)

    back_text = "Назад"
    back_color = YELLOW if menu_selection == 4 else WHITE
    surf = font.render(back_text, True, back_color)
    rect = surf.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 + 100))
    canvas.blit(surf, rect)

    hint = font.render("Стрелки влево/вправо - изменить громкость, Enter - переключить/назад", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_automation_settings():
    canvas.fill(BLACK)
    title_text = font.render("Автоматика", True, WHITE)
    title_rect = title_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 120))
    canvas.blit(title_text, title_rect)

    items = [
        "Авто-атака: " + ("Вкл" if auto_attack else "Выкл"),
        "Авто-прокачка: " + ("Вкл" if auto_upgrade else "Выкл"),
        "Авто-импланты: " + ("Вкл" if auto_implants else "Выкл"),
        "Авто-ходьба: " + ("Вкл" if auto_walk else "Выкл"),
        "Назад"
    ]
    for i, item_text in enumerate(items):
        color = YELLOW if i == menu_selection else WHITE
        surf = font.render(item_text, True, color)
        rect = surf.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 30 + i * 40))
        canvas.blit(surf, rect)

    hint = font.render("Стрелки - выбор, Enter - переключить, Shift+Enter - настроить", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_auto_upgrade_settings():
    canvas.fill(BLACK)
    title_text = font.render("Настройка авто-прокачки", True, WHITE)
    title_rect = title_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 120))
    canvas.blit(title_text, title_rect)

    y = BASE_HEIGHT // 2 - 70
    for i, uid in enumerate(ALL_UPGRADES):
        lvl = upgrade_levels[uid]
        max_block = False
        if uid == UPGRADE_REGEN and lvl >= 10:
            max_block = True
        elif uid == UPGRADE_LEVEL_FAST and lvl >= 9:
            max_block = True
        elif uid == UPGRADE_FIRERATE and lvl >= 22:
            max_block = True
        elif uid == UPGRADE_ITEM_SPAWN and lvl >= 10:
            max_block = True

        if max_block:
            status = "MAX (Выкл)"
        else:
            status = "Вкл" if uid in allowed_auto_upgrades else "Выкл"
        text = small_font.render(f"{get_permanent_upgrade_info(uid).split('[')[0].strip()}  {status}", True,
                                 YELLOW if i == menu_selection else WHITE)
        rect = text.get_rect(center=(BASE_WIDTH // 2, y))
        canvas.blit(text, rect)
        y += 30

    back_color = YELLOW if menu_selection == len(ALL_UPGRADES) else WHITE
    back_text = font.render("Назад", True, back_color)
    back_rect = back_text.get_rect(center=(BASE_WIDTH // 2, y + 10))
    canvas.blit(back_text, back_rect)

    hint = font.render("Стрелки - выбор, Enter - переключить", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_auto_implant_settings():
    canvas.fill(BLACK)
    title_text = font.render("Настройка авто-имплантов", True, WHITE)
    title_rect = title_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 120))
    canvas.blit(title_text, title_rect)

    y = BASE_HEIGHT // 2 - 70
    for i, key in enumerate(implants.keys()):
        owned = implants[key]['owned']
        if not owned:
            status = "Нет (Выкл)"
        else:
            status = "Вкл" if key in allowed_auto_implants else "Выкл"
        text = small_font.render(f"{implants[key]['name']}  {status}", True,
                                 YELLOW if i == menu_selection else WHITE)
        rect = text.get_rect(center=(BASE_WIDTH // 2, y))
        canvas.blit(text, rect)
        y += 30

    back_color = YELLOW if menu_selection == len(implants) else WHITE
    back_text = font.render("Назад", True, back_color)
    back_rect = back_text.get_rect(center=(BASE_WIDTH // 2, y + 10))
    canvas.blit(back_text, back_rect)

    hint = font.render("Стрелки - выбор, Enter - переключить", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_game_over_screen():
    overlay = pygame.Surface((BASE_WIDTH, BASE_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 200))
    canvas.blit(overlay, (0, 0))

    game_over_text = title_font.render("GAME OVER", True, RED)
    game_over_rect = game_over_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 140))
    canvas.blit(game_over_text, game_over_rect)

    earned_text = font.render(f"Получено патчей: {last_earned_patches}", True, GREEN)
    earned_rect = earned_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 80))
    canvas.blit(earned_text, earned_rect)

    menu_items = ["Новая игра", "Выйти в меню"]
    for i, item in enumerate(menu_items):
        color = YELLOW if i == menu_selection else WHITE
        text = font.render(item, True, color)
        text_rect = text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 20 + i * 60))
        canvas.blit(text, text_rect)

    hint = font.render("Стрелки - выбор, Enter - подтвердить", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_pause_menu():
    overlay = pygame.Surface((BASE_WIDTH, BASE_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    canvas.blit(overlay, (0, 0))

    title_text = font.render("ПАУЗА", True, WHITE)
    canvas.blit(title_text, (BASE_WIDTH // 2 - 60, BASE_HEIGHT // 2 - 150))

    menu_items = ["Продолжить", "Характеристики", "Настройки", "Начать заново", "Выйти в меню"]
    for i, item in enumerate(menu_items):
        color = YELLOW if i == menu_selection else WHITE
        text = font.render(item, True, color)
        text_rect = text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 60 + i * 50))
        canvas.blit(text, text_rect)

    hint = font.render("Стрелки - выбор, Enter - подтвердить, P/Esc - продолжить", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_stats_screen():
    overlay = pygame.Surface((BASE_WIDTH, BASE_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 200))
    canvas.blit(overlay, (0, 0))

    title = font.render("ХАРАКТЕРИСТИКИ", True, WHITE)
    canvas.blit(title, (BASE_WIDTH // 2 - 100, BASE_HEIGHT // 2 - 140))

    stats = [
        f"HP: {player_hp} / {player_max_hp}",
        f"Урон пули: {bullet_damage}",
        f"Скорость Лиссы: {player_speed}",
        f"Скорострельность (задержка): {shoot_delay} кадров",
        f"Бонус опыта за пакет: {xp_bonus}",
        f"Регенерация: 1 HP каждые {regen_interval//60} сек",
        f"Интервал повышения уровня: {level_interval/60:.1f} сек",
        f"Замедление вирусов: {enemy_speed_reduction}",
        f"Интервал спавна пакетов: {item_spawn_delay} кадров",
    ]

    y = BASE_HEIGHT // 2 - 90
    for line in stats:
        text = small_font.render(line, True, WHITE)
        text_rect = text.get_rect(center=(BASE_WIDTH // 2, y))
        canvas.blit(text, text_rect)
        y += 30

    hint = small_font.render("Нажмите Enter или Esc для возврата", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_upgrade_menu():
    overlay = pygame.Surface((BASE_WIDTH, BASE_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 200))
    canvas.blit(overlay, (0, 0))

    title_text = font.render("ПРОКАЧКА", True, WHITE)
    canvas.blit(title_text, (BASE_WIDTH // 2 - 90, BASE_HEIGHT // 2 - 130))

    for i, uid in enumerate(upgrade_choices):
        desc = get_upgrade_description(uid)
        color = YELLOW if i == menu_selection else WHITE
        surf = font.render(desc, True, color)
        rect = surf.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 40 + i * 50))
        canvas.blit(surf, rect)

    hint = font.render("Стрелки - выбор, Enter - подтвердить", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_workshop_menu():
    canvas.fill(BLACK)
    title_text = font.render("Сборочная станция", True, WHITE)
    title_rect = title_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 200))
    canvas.blit(title_text, title_rect)

    y = BASE_HEIGHT // 2 - 140
    for i, uid in enumerate(ALL_UPGRADES):
        color = YELLOW if i == menu_selection else WHITE
        info = get_permanent_upgrade_info(uid)
        text = small_font.render(info, True, color)
        text_rect = text.get_rect(center=(BASE_WIDTH // 2, y))
        canvas.blit(text, text_rect)
        y += 33

    reset_color = YELLOW if menu_selection == len(ALL_UPGRADES) else WHITE
    reset_text = font.render("Сбросить улучшения (вернуть патчи)", True, reset_color)
    reset_rect = reset_text.get_rect(center=(BASE_WIDTH // 2, y))
    canvas.blit(reset_text, reset_rect)
    y += 40

    back_color = YELLOW if menu_selection == len(ALL_UPGRADES) + 1 else WHITE
    back_text = font.render("Назад", True, back_color)
    back_rect = back_text.get_rect(center=(BASE_WIDTH // 2, y))
    canvas.blit(back_text, back_rect)

    patches_text = font.render(f"Патчи: {total_patches}", True, YELLOW)
    canvas.blit(patches_text, (BASE_WIDTH - patches_text.get_width() - 20, 20))

    hint = font.render("Стрелки - выбор, Enter - купить/сбросить/назад", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_implants_menu():
    canvas.fill(BLACK)
    title_text = font.render("Кибер-импланты", True, WHITE)
    title_rect = title_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 280))
    canvas.blit(title_text, title_rect)

    descs = [
        ("Бомба", "Взрывной патрон, урон по области. Перезарядка 10с."),
        ("Сбор данных", "10с спавн множества пакетов. Перезарядка 30с."),
        ("Исчезновение", "10с полупрозрачность, неуязвимость. Можно собирать пакеты. Перезарядка 30с."),
        ("Абсолютная форма", "10с +10 к скорострельности и урону. Перезарядка 60с."),
        ("Щелчок Таноса", "Наносит 10*урон всем врагам. Перезарядка 20с.")
    ]

    y = BASE_HEIGHT // 2 - 230
    for i, (name, desc) in enumerate(descs):
        imp_key = list(implants.keys())[i]
        imp = implants[imp_key]
        owned = imp['owned']
        cost = imp['cost']

        color = YELLOW if i == menu_selection else WHITE
        name_text = small_font.render(f"{name} (клавиша {i+1})", True, color)
        name_rect = name_text.get_rect(center=(BASE_WIDTH // 2, y))
        canvas.blit(name_text, name_rect)
        y += 25

        desc_color = GRAY if not owned else GREEN
        desc_text = small_font.render(desc, True, desc_color)
        desc_rect = desc_text.get_rect(center=(BASE_WIDTH // 2, y))
        canvas.blit(desc_text, desc_rect)
        y += 25

        if owned:
            status = "КУПЛЕНО"
            status_color = GREEN
        else:
            status = f"Стоимость: {cost} патчей"
            status_color = GRAY
        status_text = small_font.render(status, True, status_color)
        status_rect = status_text.get_rect(center=(BASE_WIDTH // 2, y))
        canvas.blit(status_text, status_rect)
        y += 35

    back_color = YELLOW if menu_selection == len(implants) else WHITE
    back_text = font.render("Назад", True, back_color)
    back_rect = back_text.get_rect(center=(BASE_WIDTH // 2, y + 10))
    canvas.blit(back_text, back_rect)

    patches_text = font.render(f"Патчи: {total_patches}", True, YELLOW)
    canvas.blit(patches_text, (BASE_WIDTH - patches_text.get_width() - 20, 20))

    hint = font.render("Стрелки - выбор, Enter - купить/назад", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)

def draw_checkpoint_menu():
    canvas.fill(BLACK)
    title_text = font.render("Точки восстановления", True, WHITE)
    title_rect = title_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 220))
    canvas.blit(title_text, title_rect)

    total_pages = (max_boss_defeated + 9) // 10 if max_boss_defeated > 0 else 0
    if max_boss_defeated == 0:
        no_text = font.render("Нет доступных точек", True, GRAY)
        no_rect = no_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 - 40))
        canvas.blit(no_text, no_rect)
        back_color = YELLOW if menu_selection == 0 else WHITE
        back_text = font.render("Назад", True, back_color)
        back_rect = back_text.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT // 2 + 10))
        canvas.blit(back_text, back_rect)
        hint = font.render("Стрелки - выбор, Enter - назад", True, GRAY)
        hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
        canvas.blit(hint, hint_rect)
        return

    start_idx = checkpoint_page * 10
    end_idx = min(start_idx + 10, max_boss_defeated)
    y = BASE_HEIGHT // 2 - 170
    for i in range(start_idx, end_idx):
        boss_num = i + 1
        level_after = boss_num * 30 + 1
        text = f"Босс {boss_num} (уровень {level_after})"
        color = YELLOW if i - start_idx == menu_selection else WHITE
        surf = font.render(text, True, color)
        rect = surf.get_rect(center=(BASE_WIDTH // 2, y))
        canvas.blit(surf, rect)
        y += 35

    has_prev = checkpoint_page > 0
    has_next = (checkpoint_page + 1) * 10 < max_boss_defeated
    nav_y = y
    if has_prev:
        prev_color = YELLOW if menu_selection == end_idx - start_idx else WHITE
        prev_text = font.render("<< Назад", True, prev_color)
        prev_rect = prev_text.get_rect(center=(BASE_WIDTH // 2 - 70, nav_y))
        canvas.blit(prev_text, prev_rect)
    if has_next:
        next_color = YELLOW if menu_selection == end_idx - start_idx + (1 if has_prev else 0) else WHITE
        next_text = font.render("Далее >>", True, next_color)
        next_rect = next_text.get_rect(center=(BASE_WIDTH // 2 + 70, nav_y))
        canvas.blit(next_text, next_rect)

    back_idx = end_idx - start_idx + (1 if has_prev else 0) + (1 if has_next else 0)
    back_color = YELLOW if menu_selection == back_idx else WHITE
    back_text = font.render("Назад", True, back_color)
    back_rect = back_text.get_rect(center=(BASE_WIDTH // 2, nav_y + 20))
    canvas.blit(back_text, back_rect)

    hint = font.render("Стрелки - выбор, Enter - активировать точку", True, GRAY)
    hint_rect = hint.get_rect(center=(BASE_WIDTH // 2, BASE_HEIGHT - 40))
    canvas.blit(hint, hint_rect)
running = True
while running:
    current_keys = pygame.key.get_pressed()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # --- Обработка кликов мыши / касаний для меню (все экраны, кроме игры) ---
        if state != STATE_PLAYING and event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
            if event.type == pygame.MOUSEBUTTONDOWN:
                fx, fy = event.pos
                if not fullscreen:
                    pass
                else:
                    scale_x = screen.get_width() / BASE_WIDTH
                    scale_y = screen.get_height() / BASE_HEIGHT
                    fx /= scale_x
                    fy /= scale_y
            elif event.type == pygame.FINGERDOWN:
                fx = event.x * BASE_WIDTH
                fy = event.y * BASE_HEIGHT

            def get_menu_rects():
                if state == STATE_SAVE_SELECT:
                    rects = []
                    for i in range(3):
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 80 + i*60, 300, 40))
                    rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 + 100, 300, 40))  # выход
                    return rects
                elif state == STATE_MENU:
                    rects = []
                    # draw_main_menu: y = BASE_HEIGHT//2 - 80 + i*50
                    for i in range(6):
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 110 + i*50, 300, 40))
                    return rects
                elif state == STATE_SETTINGS:
                    rects = []
                    # draw_settings_menu: y = BASE_HEIGHT//2 - 40 + i*50
                    for i in range(4):
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 90 + i*50, 300, 40))
                    return rects
                elif state == STATE_AUDIO_SETTINGS:
                    rects = []
                    # draw_audio_settings: y = BASE_HEIGHT//2 - 90 + i*40 (5 пунктов)
                    for i in range(5):
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 90 + i*40, 300, 40))
                    return rects
                elif state == STATE_AUTOMATION_SETTINGS:
                    rects = []
                    # draw_automation_settings: y = BASE_HEIGHT//2 - 80 + i*40
                    for i in range(5):
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 80 + i*40, 300, 40))
                    return rects
                elif state == STATE_AUTO_UPGRADE_SETTINGS:
                    rects = []
                    # draw_auto_upgrade_settings: y = BASE_HEIGHT//2 - 100 + i*30 (10 улучшений + назад)
                    for i in range(len(ALL_UPGRADES)):
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 100 + i*30, 300, 25))
                    rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 + 200, 300, 40))  # назад
                    return rects
                elif state == STATE_AUTO_IMPLANT_SETTINGS:
                    rects = []
                    # draw_auto_implant_settings: y = BASE_HEIGHT//2 - 80 + i*30 (5 имплантов + назад)
                    for i in range(5):
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 80 + i*30, 300, 25))
                    rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 + 200, 300, 40))
                    return rects
                elif state == STATE_WORKSHOP:
                    rects = []
                    # draw_workshop_menu: y = BASE_HEIGHT//2 - 160 + i*33 (10 улучшений)
                    for i in range(len(ALL_UPGRADES)):
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 160 + i*33, 300, 25))
                    rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 + 170, 300, 40))  # сброс
                    rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 + 210, 300, 40))  # назад
                    return rects
                elif state == STATE_IMPLANTS:
                    rects = []
                    # draw_implants_menu: y = BASE_HEIGHT//2 - 200 + i*85 (5 имплантов)
                    for i in range(5):
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 200 + i*85, 300, 80))
                    rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 + 250, 300, 40))  # назад
                    return rects
                elif state == STATE_CHECKPOINTS:
                    rects = []
                    if max_boss_defeated == 0:
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 + 40, 300, 40))
                    else:
                        items = min(10, max_boss_defeated - checkpoint_page*10)
                        for i in range(items):
                            rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 150 + i*35, 300, 25))
                        if checkpoint_page > 0:
                            rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 + 150, 150, 40))
                        if (checkpoint_page+1)*10 < max_boss_defeated:
                            rects.append(pygame.Rect(BASE_WIDTH//2 + 20, BASE_HEIGHT//2 + 150, 150, 40))
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 + 190, 300, 40))
                    return rects
                elif state == STATE_GAME_OVER:
                    rects = []
                    for i in range(2):
                        rects.append(pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 40 + i*60, 300, 40))
                    return rects
                return []

            rects = get_menu_rects()
            for i, r in enumerate(rects):
                if r.collidepoint(fx, fy):
                    menu_selection = i
                    newevent = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN)
                    pygame.event.post(newevent)
                    break

        # --- Обработка кликов в паузе и меню прокачки внутри игры ---
        if state == STATE_PLAYING and (paused or upgrade_menu) and event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
            if event.type == pygame.MOUSEBUTTONDOWN:
                fx, fy = event.pos
                if not fullscreen:
                    pass
                else:
                    scale_x = screen.get_width() / BASE_WIDTH
                    scale_y = screen.get_height() / BASE_HEIGHT
                    fx /= scale_x
                    fy /= scale_y
            elif event.type == pygame.FINGERDOWN:
                fx = event.x * BASE_WIDTH
                fy = event.y * BASE_HEIGHT

            # Меню паузы (5 пунктов: Продолжить, Характеристики, Настройки, Начать заново, Выйти в меню)
            if paused and not upgrade_menu:
                # draw_pause_menu: y = BASE_HEIGHT//2 - 60 + i*50
                for i in range(5):
                    r = pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 80 + i*50, 300, 40)
                    if r.collidepoint(fx, fy):
                        menu_selection = i
                        newevent = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN)
                        pygame.event.post(newevent)
                        break
            # Меню прокачки (3 случайных улучшения)
            elif upgrade_menu:
                # draw_upgrade_menu: y = BASE_HEIGHT//2 - 40 + i*50
                for i in range(3):
                    r = pygame.Rect(BASE_WIDTH//2 - 150, BASE_HEIGHT//2 - 60 + i*50, 300, 40)
                    if r.collidepoint(fx, fy):
                        menu_selection = i
                        newevent = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN)
                        pygame.event.post(newevent)
                        break

        # --- Касания / клики мышью в игре (графические кнопки) ---
        if state == STATE_PLAYING and not paused and not upgrade_menu:
            # Нажатие
            if event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.FINGERDOWN:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    fx, fy = event.pos
                    if not fullscreen:
                        pass
                    else:
                        scale_x = screen.get_width() / BASE_WIDTH
                        scale_y = screen.get_height() / BASE_HEIGHT
                        fx /= scale_x
                        fy /= scale_y
                elif event.type == pygame.FINGERDOWN:
                    fx = event.x * BASE_WIDTH
                    fy = event.y * BASE_HEIGHT

                if shoot_rect.collidepoint(fx, fy):
                    touch_buttons["shoot"] = True
                elif crouch_rect.collidepoint(fx, fy):
                    touch_buttons["crouch"] = True
                elif left_rect.collidepoint(fx, fy):
                    touch_buttons["left"] = True
                elif right_rect.collidepoint(fx, fy):
                    touch_buttons["right"] = True
                elif pause_rect.collidepoint(fx, fy):
                    if not paused and not upgrade_menu and not showing_stats:
                        paused = True
                        menu_selection = 0
                else:
                    for key, r in implant_rects.items():
                        if r.collidepoint(fx, fy) and implants[key]['owned']:
                            touch_buttons[key] = True
                            break

            # Отпускание
            if event.type == pygame.MOUSEBUTTONUP or event.type == pygame.FINGERUP:
                if event.type == pygame.MOUSEBUTTONUP:
                    fx, fy = event.pos
                    if not fullscreen:
                        pass
                    else:
                        scale_x = screen.get_width() / BASE_WIDTH
                        scale_y = screen.get_height() / BASE_HEIGHT
                        fx /= scale_x
                        fy /= scale_y
                elif event.type == pygame.FINGERUP:
                    fx = event.x * BASE_WIDTH
                    fy = event.y * BASE_HEIGHT

                if shoot_rect.collidepoint(fx, fy):
                    touch_buttons["shoot"] = False
                elif crouch_rect.collidepoint(fx, fy):
                    touch_buttons["crouch"] = False
                elif left_rect.collidepoint(fx, fy):
                    touch_buttons["left"] = False
                elif right_rect.collidepoint(fx, fy):
                    touch_buttons["right"] = False
                else:
                    for key, r in implant_rects.items():
                        if r.collidepoint(fx, fy):
                            touch_buttons[key] = False
                            break

        # --- Клавиатурные события (полный блок, без изменений) ---
        if event.type == pygame.KEYDOWN:
            if state == STATE_SAVE_SELECT:
                if event.key == pygame.K_UP:
                    selected_save_index = (selected_save_index - 1) % 4
                elif event.key == pygame.K_DOWN:
                    selected_save_index = (selected_save_index + 1) % 4
                elif event.key == pygame.K_RETURN:
                    if selected_save_index < 3:
                        if current_keys[pygame.K_LSHIFT] or current_keys[pygame.K_RSHIFT]:
                            if os.path.exists(SAVE_FILES[selected_save_index]):
                                os.remove(SAVE_FILES[selected_save_index])
                        else:
                            current_save_slot = SAVE_FILES[selected_save_index]
                            if os.path.exists(current_save_slot):
                                load_game(current_save_slot)
                            else:
                                save_game(current_save_slot)
                            apply_permanent_upgrades()
                            apply_audio_settings()
                            state = STATE_MENU
                            menu_selection = 0
                            set_music(get_menu_music())
                    else:
                        running = False

            elif state == STATE_MENU:
                if event.key == pygame.K_UP:
                    menu_selection = (menu_selection - 1) % 6
                elif event.key == pygame.K_DOWN:
                    menu_selection = (menu_selection + 1) % 6
                elif event.key == pygame.K_RETURN:
                    if menu_selection == 0:
                        reset_game()
                        state = STATE_PLAYING
                    elif menu_selection == 1:
                        state = STATE_WORKSHOP
                        menu_selection = 0
                    elif menu_selection == 2:
                        state = STATE_IMPLANTS
                        menu_selection = 0
                    elif menu_selection == 3:
                        state = STATE_CHECKPOINTS
                        checkpoint_page = 0
                        menu_selection = 0
                    elif menu_selection == 4:
                        state = STATE_SETTINGS
                        menu_selection = 0
                    elif menu_selection == 5:
                        running = False

            elif state == STATE_SETTINGS:
                if event.key == pygame.K_UP:
                    menu_selection = (menu_selection - 1) % 4
                elif event.key == pygame.K_DOWN:
                    menu_selection = (menu_selection + 1) % 4
                elif event.key == pygame.K_RETURN:
                    if menu_selection == 0:
                        fullscreen = not fullscreen
                        apply_display_mode()
                    elif menu_selection == 1:
                        state = STATE_AUDIO_SETTINGS
                        menu_selection = 0
                    elif menu_selection == 2:
                        state = STATE_AUTOMATION_SETTINGS
                        menu_selection = 0
                    elif menu_selection == 3:
                        if settings_from_pause:
                            state = STATE_PLAYING
                            paused = True
                            settings_from_pause = False
                        else:
                            state = STATE_MENU
                            menu_selection = 4

            elif state == STATE_AUDIO_SETTINGS:
                if event.key == pygame.K_UP:
                    menu_selection = (menu_selection - 1) % 5
                elif event.key == pygame.K_DOWN:
                    menu_selection = (menu_selection + 1) % 5
                elif event.key == pygame.K_LEFT:
                    if menu_selection == 0:
                        music_volume = max(0, music_volume - 5)
                        apply_audio_settings()
                    elif menu_selection == 1:
                        sfx_volume = max(0, sfx_volume - 5)
                        apply_audio_settings()
                        if sounds_loaded and shoot_sound_enabled:
                            sound_shoot.play()
                elif event.key == pygame.K_RIGHT:
                    if menu_selection == 0:
                        music_volume = min(100, music_volume + 5)
                        apply_audio_settings()
                    elif menu_selection == 1:
                        sfx_volume = min(100, sfx_volume + 5)
                        apply_audio_settings()
                        if sounds_loaded and shoot_sound_enabled:
                            sound_shoot.play()
                elif event.key == pygame.K_RETURN:
                    if menu_selection == 2:
                        shoot_sound_enabled = not shoot_sound_enabled
                    elif menu_selection == 3:
                        alternative_music = not alternative_music
                        if state == STATE_PLAYING:
                            set_music(get_battle_music())
                        else:
                            set_music(get_menu_music())
                    elif menu_selection == 4:
                        if current_save_slot:
                            save_game(current_save_slot)
                        state = STATE_SETTINGS
                        menu_selection = 1

            elif state == STATE_AUTOMATION_SETTINGS:
                if event.key == pygame.K_UP:
                    menu_selection = (menu_selection - 1) % 5
                elif event.key == pygame.K_DOWN:
                    menu_selection = (menu_selection + 1) % 5
                elif event.key == pygame.K_RETURN:
                    if current_keys[pygame.K_LSHIFT] or current_keys[pygame.K_RSHIFT]:
                        if menu_selection == 1:
                            state = STATE_AUTO_UPGRADE_SETTINGS
                            menu_selection = 0
                        elif menu_selection == 2:
                            state = STATE_AUTO_IMPLANT_SETTINGS
                            menu_selection = 0
                        else:
                            if menu_selection == 0:
                                auto_attack = not auto_attack
                            elif menu_selection == 3:
                                auto_walk = not auto_walk
                    else:
                        if menu_selection == 0:
                            auto_attack = not auto_attack
                        elif menu_selection == 1:
                            auto_upgrade = not auto_upgrade
                        elif menu_selection == 2:
                            auto_implants = not auto_implants
                        elif menu_selection == 3:
                            auto_walk = not auto_walk
                        elif menu_selection == 4:
                            if current_save_slot:
                                save_game(current_save_slot)
                            state = STATE_SETTINGS
                            menu_selection = 2

            elif state == STATE_AUTO_UPGRADE_SETTINGS:
                if event.key == pygame.K_UP:
                    menu_selection = (menu_selection - 1) % (len(ALL_UPGRADES) + 1)
                elif event.key == pygame.K_DOWN:
                    menu_selection = (menu_selection + 1) % (len(ALL_UPGRADES) + 1)
                elif event.key == pygame.K_RETURN:
                    if menu_selection < len(ALL_UPGRADES):
                        uid = ALL_UPGRADES[menu_selection]
                        lvl = upgrade_levels[uid]
                        max_block = False
                        if uid == UPGRADE_REGEN and lvl >= 10:
                            max_block = True
                        elif uid == UPGRADE_LEVEL_FAST and lvl >= 9:
                            max_block = True
                        elif uid == UPGRADE_FIRERATE and lvl >= 22:
                            max_block = True
                        elif uid == UPGRADE_ITEM_SPAWN and lvl >= 10:
                            max_block = True
                        if not max_block:
                            if uid in allowed_auto_upgrades:
                                allowed_auto_upgrades.remove(uid)
                            else:
                                allowed_auto_upgrades.append(uid)
                    else:
                        state = STATE_AUTOMATION_SETTINGS
                        menu_selection = 1
                        if current_save_slot:
                            save_game(current_save_slot)

            elif state == STATE_AUTO_IMPLANT_SETTINGS:
                if event.key == pygame.K_UP:
                    menu_selection = (menu_selection - 1) % (len(implants) + 1)
                elif event.key == pygame.K_DOWN:
                    menu_selection = (menu_selection + 1) % (len(implants) + 1)
                elif event.key == pygame.K_RETURN:
                    if menu_selection < len(implants):
                        key = list(implants.keys())[menu_selection]
                        if implants[key]['owned']:
                            if key in allowed_auto_implants:
                                allowed_auto_implants.remove(key)
                            else:
                                allowed_auto_implants.append(key)
                    else:
                        state = STATE_AUTOMATION_SETTINGS
                        menu_selection = 2
                        if current_save_slot:
                            save_game(current_save_slot)

            elif state == STATE_WORKSHOP:
                total_items = len(ALL_UPGRADES) + 2
                if event.key == pygame.K_UP:
                    menu_selection = (menu_selection - 1) % total_items
                elif event.key == pygame.K_DOWN:
                    menu_selection = (menu_selection + 1) % total_items
                elif event.key == pygame.K_RETURN:
                    if menu_selection < len(ALL_UPGRADES):
                        uid = ALL_UPGRADES[menu_selection]
                        lvl = upgrade_levels[uid]
                        max_block = False
                        if uid == UPGRADE_REGEN and lvl >= 10:
                            max_block = True
                        elif uid == UPGRADE_LEVEL_FAST and lvl >= 9:
                            max_block = True
                        elif uid == UPGRADE_FIRERATE and lvl >= 22:
                            max_block = True
                        elif uid == UPGRADE_ITEM_SPAWN and lvl >= 10:
                            max_block = True
                        if not max_block:
                            if current_keys[pygame.K_LSHIFT] or current_keys[pygame.K_RSHIFT]:
                                if uid == UPGRADE_REGEN:
                                    max_possible = 10
                                elif uid == UPGRADE_LEVEL_FAST:
                                    max_possible = 9
                                elif uid == UPGRADE_FIRERATE:
                                    max_possible = 22
                                elif uid == UPGRADE_ITEM_SPAWN:
                                    max_possible = 10
                                else:
                                    max_possible = 9999
                                target_lvl = min(lvl + 10, max_possible)
                                levels_to_buy = target_lvl - lvl
                                total_cost = 0
                                for i in range(lvl, target_lvl):
                                    total_cost += 5 + 5 * i
                                if total_patches >= total_cost:
                                    total_patches -= total_cost
                                    for _ in range(levels_to_buy):
                                        upgrade_levels[uid] += 1
                                    if current_save_slot:
                                        save_game(current_save_slot)
                                    if sounds_loaded:
                                        sound_purchase.play()
                            else:
                                cost = 5 + 5 * lvl
                                if total_patches >= cost:
                                    total_patches -= cost
                                    upgrade_levels[uid] += 1
                                    if current_save_slot:
                                        save_game(current_save_slot)
                                    if sounds_loaded:
                                        sound_purchase.play()
                    elif menu_selection == len(ALL_UPGRADES):
                        reset_workshop_upgrades()
                    else:
                        state = STATE_MENU
                        menu_selection = 1

            elif state == STATE_IMPLANTS:
                total_items = len(implants) + 1
                if event.key == pygame.K_UP:
                    menu_selection = (menu_selection - 1) % total_items
                elif event.key == pygame.K_DOWN:
                    menu_selection = (menu_selection + 1) % total_items
                elif event.key == pygame.K_RETURN:
                    if menu_selection < len(implants):
                        keys_list = list(implants.keys())
                        imp_key = keys_list[menu_selection]
                        imp = implants[imp_key]
                        if not imp['owned'] and total_patches >= imp['cost']:
                            total_patches -= imp['cost']
                            imp['owned'] = True
                            imp['timer'] = 0
                            if current_save_slot:
                                save_game(current_save_slot)
                            if sounds_loaded:
                                sound_purchase.play()
                    else:
                        state = STATE_MENU
                        menu_selection = 2

            elif state == STATE_CHECKPOINTS:
                if max_boss_defeated == 0:
                    if event.key == pygame.K_UP:
                        menu_selection = (menu_selection - 1) % 1
                    elif event.key == pygame.K_DOWN:
                        menu_selection = (menu_selection + 1) % 1
                    elif event.key == pygame.K_RETURN:
                        state = STATE_MENU
                        menu_selection = 3
                else:
                    items_on_page = min(10, max_boss_defeated - checkpoint_page * 10)
                    has_prev = checkpoint_page > 0
                    has_next = (checkpoint_page + 1) * 10 < max_boss_defeated
                    total_actions = items_on_page + (1 if has_prev else 0) + (1 if has_next else 0) + 1
                    if event.key == pygame.K_UP:
                        menu_selection = (menu_selection - 1) % total_actions
                    elif event.key == pygame.K_DOWN:
                        menu_selection = (menu_selection + 1) % total_actions
                    elif event.key == pygame.K_RETURN:
                        if menu_selection < items_on_page:
                            boss_num = checkpoint_page * 10 + menu_selection + 1
                            start_game_from_checkpoint(boss_num)
                        elif has_prev and menu_selection == items_on_page:
                            checkpoint_page -= 1
                            menu_selection = 0
                        elif has_next and menu_selection == items_on_page + (1 if has_prev else 0):
                            checkpoint_page += 1
                            menu_selection = 0
                        elif menu_selection == total_actions - 1:
                            state = STATE_MENU
                            menu_selection = 3

            elif state == STATE_PLAYING:
                if showing_stats:
                    if event.key in (pygame.K_RETURN, pygame.K_ESCAPE):
                        showing_stats = False
                elif upgrade_menu:
                    if event.key == pygame.K_UP:
                        menu_selection = (menu_selection - 1) % 3
                    elif event.key == pygame.K_DOWN:
                        menu_selection = (menu_selection + 1) % 3
                    elif event.key == pygame.K_RETURN:
                        chosen = upgrade_choices[menu_selection]
                        apply_upgrade(chosen)
                        xp -= xp_to_next
                        xp_to_next += 25
                        upgrade_menu = False
                        paused = False
                        menu_selection = 0
                elif paused:
                    if event.key == pygame.K_UP:
                        menu_selection = (menu_selection - 1) % 5
                    elif event.key == pygame.K_DOWN:
                        menu_selection = (menu_selection + 1) % 5
                    elif event.key == pygame.K_RETURN:
                        if menu_selection == 0:
                            paused = False
                        elif menu_selection == 1:
                            showing_stats = True
                        elif menu_selection == 2:
                            settings_from_pause = True
                            state = STATE_SETTINGS
                            menu_selection = 0
                        elif menu_selection == 3:
                            reset_game()
                        elif menu_selection == 4:
                            state = STATE_MENU
                            menu_selection = 0
                            enemies.clear()
                            bullets.clear()
                            items.clear()
                    elif event.key in (pygame.K_p, pygame.K_ESCAPE):
                        paused = False
                        menu_selection = 0
                else:
                    if event.key in (pygame.K_p, pygame.K_ESCAPE):
                        paused = True
                        menu_selection = 0
                    else:
                        for key, imp in implants.items():
                            if event.key == imp['key'] and imp['owned'] and imp.get('timer', 0) == 0:
                                imp['timer'] = imp['cooldown']
                                if key != "bomb" and sounds_loaded and key in implant_sounds and implant_sounds[key]:
                                    implant_sounds[key].play()
                                if key == "bomb":
                                    bombs.append({
                                        'rect': pygame.Rect(player_x + player_width // 2 - 10, player_y - 10, 20, 20),
                                        'speed': 5,
                                        'timer': 60
                                    })
                                elif key == "data":
                                    imp['duration_timer'] = imp['duration']
                                elif key == "vanish":
                                    imp['duration_timer'] = imp['duration']
                                elif key == "absolute":
                                    imp['duration_timer'] = 600
                                elif key == "thanos":
                                    for enemy in enemies[:]:
                                        enemy['hp'] -= 10 * bullet_damage
                                        if enemy['hp'] <= 0:
                                            enemies.remove(enemy)
                                            score += 20
                                    if boss_active and boss is not None:
                                        boss['hp'] -= 10 * bullet_damage
                                        if boss['hp'] <= 0:
                                            score += 500 * boss_number
                                            level += 1
                                            boss = None
                                            boss_active = False
                                            level_timer = level_interval
                                            if boss_number > max_boss_defeated:
                                                max_boss_defeated = boss_number

            elif state == STATE_GAME_OVER:
                if event.key == pygame.K_UP:
                    menu_selection = (menu_selection - 1) % 2
                elif event.key == pygame.K_DOWN:
                    menu_selection = (menu_selection + 1) % 2
                elif event.key == pygame.K_RETURN:
                    if menu_selection == 0:
                        reset_game()
                    elif menu_selection == 1:
                        state = STATE_MENU
                        menu_selection = 0
                        enemies.clear()
                        bullets.clear()
                        items.clear()

    # Управление музыкой
    if state in (STATE_MENU, STATE_SETTINGS, STATE_AUDIO_SETTINGS, STATE_AUTOMATION_SETTINGS,
                 STATE_AUTO_UPGRADE_SETTINGS, STATE_AUTO_IMPLANT_SETTINGS, STATE_WORKSHOP, STATE_IMPLANTS, STATE_CHECKPOINTS):
        set_music(get_menu_music())
    elif state == STATE_PLAYING:
        set_music(get_battle_music())

    # ------------------------------------------------------------
    if state == STATE_PLAYING and not paused and not showing_stats and not upgrade_menu:
        keys = pygame.key.get_pressed()

        # Направления с клавиатуры + кнопки касания (или мыши)
        move_left = keys[pygame.K_LEFT] or touch_buttons.get("left", False)
        move_right = keys[pygame.K_RIGHT] or touch_buttons.get("right", False)
        crouch = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT] or touch_buttons.get("crouch", False)
        shoot = keys[pygame.K_SPACE] or auto_attack or touch_buttons.get("shoot", False)

        if auto_walk and not move_left and not move_right:
            player_x += auto_walk_dir * player_speed
            if player_x <= 0:
                player_x = 0
                auto_walk_dir = 1
            elif player_x >= BASE_WIDTH - player_width:
                player_x = BASE_WIDTH - player_width
                auto_walk_dir = -1
        else:
            current_speed = 3 if crouch else player_speed
            if move_left and player_x > 0:
                player_x -= current_speed
            if move_right and player_x < BASE_WIDTH - player_width:
                player_x += current_speed

        if shoot and shoot_cooldown == 0:
            spawn_bullet()
            if implants["absolute"].get('duration_timer', 0) > 0:
                shoot_cooldown = max(3, shoot_delay - 10)
            else:
                shoot_cooldown = shoot_delay

        if shoot_cooldown > 0:
            shoot_cooldown -= 1

        if invincible_timer > 0:
            invincible_timer -= 1

        if regen_interval > 0:
            regen_timer -= 1
            if regen_timer <= 0:
                regen_timer = regen_interval
                if player_hp < player_max_hp:
                    player_hp += 1

        for key, imp in implants.items():
            if imp.get('timer', 0) > 0:
                imp['timer'] -= 1
            if imp.get('duration_timer', 0) > 0:
                imp['duration_timer'] -= 1

        if auto_implants:
            for key in allowed_auto_implants:
                imp = implants[key]
                if imp['owned'] and imp.get('timer', 0) == 0:
                    imp['timer'] = imp['cooldown']
                    if key != "bomb" and sounds_loaded and key in implant_sounds and implant_sounds[key]:
                        implant_sounds[key].play()
                    if key == "bomb":
                        bombs.append({
                            'rect': pygame.Rect(player_x + player_width // 2 - 10, player_y - 10, 20, 20),
                            'speed': 5,
                            'timer': 60
                        })
                    elif key == "data":
                        imp['duration_timer'] = imp['duration']
                    elif key == "vanish":
                        imp['duration_timer'] = imp['duration']
                    elif key == "absolute":
                        imp['duration_timer'] = 600
                    elif key == "thanos":
                        for enemy in enemies[:]:
                            enemy['hp'] -= 10 * bullet_damage
                            if enemy['hp'] <= 0:
                                enemies.remove(enemy)
                                score += 20
                        if boss_active and boss is not None:
                            boss['hp'] -= 10 * bullet_damage
                            if boss['hp'] <= 0:
                                score += 500 * boss_number
                                level += 1
                                boss = None
                                boss_active = False
                                level_timer = level_interval
                                if boss_number > max_boss_defeated:
                                    max_boss_defeated = boss_number

        # Активация имплантов касанием (кнопки)
        for key, imp in implants.items():
            if touch_buttons.get(key, False) and imp['owned'] and imp.get('timer', 0) == 0:
                imp['timer'] = imp['cooldown']
                touch_buttons[key] = False
                if key != "bomb" and sounds_loaded and key in implant_sounds and implant_sounds[key]:
                    implant_sounds[key].play()
                if key == "bomb":
                    bombs.append({
                        'rect': pygame.Rect(player_x + player_width // 2 - 10, player_y - 10, 20, 20),
                        'speed': 5,
                        'timer': 60
                    })
                elif key == "data":
                    imp['duration_timer'] = imp['duration']
                elif key == "vanish":
                    imp['duration_timer'] = imp['duration']
                elif key == "absolute":
                    imp['duration_timer'] = 600
                elif key == "thanos":
                    for enemy in enemies[:]:
                        enemy['hp'] -= 10 * bullet_damage
                        if enemy['hp'] <= 0:
                            enemies.remove(enemy)
                            score += 20
                    if boss_active and boss is not None:
                        boss['hp'] -= 10 * bullet_damage
                        if boss['hp'] <= 0:
                            score += 500 * boss_number
                            level += 1
                            boss = None
                            boss_active = False
                            level_timer = level_interval
                            if boss_number > max_boss_defeated:
                                max_boss_defeated = boss_number

        if not boss_active and level % 30 == 0 and level > 0:
            spawn_boss()

        # --- ЛОГИКА БОССА ---
        if boss_active:
            if boss['state'] == 'spawning':
                boss['rect'].y += 1
                if boss['rect'].y >= BOSS_IDLE_Y:
                    boss['rect'].y = BOSS_IDLE_Y
                    boss['state'] = 'idle'
            else:
                boss['shoot_timer'] -= 1
                boss['summon_timer'] -= 1
                boss['rush_timer'] -= 1

                if boss['rush_active']:
                    boss['rush_duration'] -= 1
                    if boss['rush_duration'] <= 0:
                        boss['rush_active'] = False
                        if boss['rush_direction'] < 0:
                            boss['speed_x'] = -2
                        else:
                            boss['speed_x'] = 2
                    else:
                        boss['rect'].x += boss['rush_direction'] * boss['rush_speed']
                        player_rect = pygame.Rect(player_x, player_y, player_width, player_height)
                        if boss['rect'].colliderect(player_rect) and invincible_timer == 0:
                            player_hp -= 1
                            invincible_timer = 60
                            if player_hp <= 0:
                                state = STATE_GAME_OVER
                                menu_selection = 0
                                if not patches_earned:
                                    last_earned_patches = level + score // 10
                                    total_patches += last_earned_patches
                                    patches_earned = True
                                    if current_save_slot:
                                        save_game(current_save_slot)
                                if sounds_loaded:
                                    sound_death.play()
                else:
                    boss['rect'].x += boss['speed_x']
                    if boss['rect'].left <= 0:
                        boss['rect'].left = 0
                        boss['speed_x'] = abs(boss['speed_x'])
                    elif boss['rect'].right >= BASE_WIDTH:
                        boss['rect'].right = BASE_WIDTH
                        boss['speed_x'] = -abs(boss['speed_x'])

                    if boss['rush_timer'] <= 0:
                        boss['rush_active'] = True
                        boss['rush_duration'] = 30
                        if player_x + player_width/2 > boss['rect'].centerx:
                            boss['rush_direction'] = 1
                        else:
                            boss['rush_direction'] = -1
                        boss['rush_timer'] = 180

                if boss['shoot_timer'] <= 0 and not boss['rush_active']:
                    base_angle = math.atan2(player_y + player_height/2 - boss['rect'].centery,
                                            player_x + player_width/2 - boss['rect'].centerx)
                    for i in range(-2, 3):
                        angle = base_angle + i * 0.2
                        speed = 6
                        boss_bullets.append({
                            'rect': pygame.Rect(boss['rect'].centerx - 5, boss['rect'].centery - 5, 10, 10),
                            'vx': speed * math.cos(angle),
                            'vy': speed * math.sin(angle),
                            'damage': 1 * boss_number
                        })
                    boss['shoot_timer'] = 120

                if boss['summon_timer'] <= 0 and not boss['rush_active']:
                    for _ in range(random.randint(2, 3)):
                        spawn_enemy()
                    boss['summon_timer'] = 300

                if boss['hp'] <= 0:
                    score += 500 * boss_number
                    level += 1
                    if boss_number > max_boss_defeated:
                        max_boss_defeated = boss_number
                        if current_save_slot:
                            save_game(current_save_slot)
                    boss = None
                    boss_active = False
                    level_timer = level_interval
                    if sounds_loaded:
                        sound_boss_win.play()
        else:
            level_timer -= 1
            if level_timer <= 0:
                level += 1
                level_timer = level_interval

            frame_count += 1
            if frame_count % max(10, enemy_spawn_rate - level) == 0:
                spawn_enemy()
            if implants["data"].get('duration_timer', 0) > 0:
                if frame_count % 5 == 0:
                    spawn_item()
            else:
                current_item_delay = max(10, item_spawn_delay - level // 2)
                if frame_count % current_item_delay == 0:
                    spawn_item()

        # ---------- ОБРАБОТКА СНАРЯДОВ БОССА ----------
        for bullet in boss_bullets[:]:
            bullet['rect'].x += bullet['vx']
            bullet['rect'].y += bullet['vy']
            player_rect = pygame.Rect(player_x, player_y, player_width, player_height)
            if bullet['rect'].colliderect(player_rect) and invincible_timer == 0:
                player_hp -= bullet['damage']
                invincible_timer = 60
                boss_bullets.remove(bullet)
                if player_hp <= 0:
                    state = STATE_GAME_OVER
                    menu_selection = 0
                    if not patches_earned:
                        last_earned_patches = level + score // 10
                        total_patches += last_earned_patches
                        patches_earned = True
                        if current_save_slot:
                            save_game(current_save_slot)
                    if sounds_loaded:
                        sound_death.play()
            elif (bullet['rect'].bottom < 0 or bullet['rect'].top > BASE_HEIGHT or
                  bullet['rect'].left < 0 or bullet['rect'].right > BASE_WIDTH):
                boss_bullets.remove(bullet)

        player_rect = pygame.Rect(player_x, player_y, player_width, player_height)
        player_vanished = implants["vanish"].get('duration_timer', 0) > 0

        # ---------- БОМБЫ ИГРОКА ----------
        for bomb in bombs[:]:
            bomb['timer'] -= 1
            bomb['rect'].y -= bomb['speed']
            if bomb['timer'] <= 0 or bomb['rect'].bottom < 0:
                if sounds_loaded and "bomb" in implant_sounds and implant_sounds["bomb"]:
                    implant_sounds["bomb"].play()
                explosion_damage = bullet_damage * 3
                for e in enemies[:]:
                    dist = math.hypot(e['rect'].centerx - bomb['rect'].centerx,
                                      e['rect'].centery - bomb['rect'].centery)
                    if dist < 120:
                        e['hp'] -= explosion_damage
                        if e['hp'] <= 0:
                            enemies.remove(e)
                            score += 10 * (boss_number + 1)
                if boss_active and boss is not None:
                    dist = math.hypot(boss['rect'].centerx - bomb['rect'].centerx,
                                      boss['rect'].centery - bomb['rect'].centery)
                    if dist < 120:
                        boss['hp'] -= explosion_damage
                bombs.remove(bomb)
                explosions.append({'pos': bomb['rect'].center, 'timer': 10})
                continue
            hit = False
            for enemy in enemies[:]:
                if bomb['rect'].colliderect(enemy['rect']):
                    if sounds_loaded and "bomb" in implant_sounds and implant_sounds["bomb"]:
                        implant_sounds["bomb"].play()
                    explosion_damage = bullet_damage * 3
                    for e in enemies[:]:
                        dist = math.hypot(e['rect'].centerx - bomb['rect'].centerx,
                                          e['rect'].centery - bomb['rect'].centery)
                        if dist < 120:
                            e['hp'] -= explosion_damage
                            if e['hp'] <= 0:
                                enemies.remove(e)
                                score += 10 * (boss_number + 1)
                    if boss_active and boss is not None:
                        dist = math.hypot(boss['rect'].centerx - bomb['rect'].centerx,
                                          boss['rect'].centery - bomb['rect'].centery)
                        if dist < 120:
                            boss['hp'] -= explosion_damage
                    bombs.remove(bomb)
                    explosions.append({'pos': bomb['rect'].center, 'timer': 10})
                    hit = True
                    break
            if not hit and boss_active and boss is not None and bomb['rect'].colliderect(boss['rect']):
                if sounds_loaded and "bomb" in implant_sounds and implant_sounds["bomb"]:
                    implant_sounds["bomb"].play()
                explosion_damage = bullet_damage * 3
                for e in enemies[:]:
                    dist = math.hypot(e['rect'].centerx - bomb['rect'].centerx,
                                      e['rect'].centery - bomb['rect'].centery)
                    if dist < 120:
                        e['hp'] -= explosion_damage
                        if e['hp'] <= 0:
                            enemies.remove(e)
                            score += 10 * (boss_number + 1)
                if boss_active and boss is not None:
                    dist = math.hypot(boss['rect'].centerx - bomb['rect'].centerx,
                                      boss['rect'].centery - bomb['rect'].centery)
                    if dist < 120:
                        boss['hp'] -= explosion_damage
                bombs.remove(bomb)
                explosions.append({'pos': bomb['rect'].center, 'timer': 10})

        # ---------- ОБНОВЛЕНИЕ ВРАГОВ ----------
        enemy_damage = 1 + boss_number
        for enemy in enemies[:]:
            enemy_type = enemy.get('type', 'normal')
            if enemy_type == 'shooter':
                enemy['rect'].x += enemy.get('speed', 2) * enemy.get('dir', 1)
                if enemy['rect'].left <= 0 or enemy['rect'].right >= BASE_WIDTH:
                    enemy['dir'] *= -1
                enemy['shoot_timer'] = enemy.get('shoot_timer', 0) - 1
                if enemy['shoot_timer'] <= 0:
                    enemy['shoot_timer'] = random.randint(60, 120)
                    bullets.append({
                        'rect': pygame.Rect(enemy['rect'].centerx - 3, enemy['rect'].bottom, 6, 12),
                        'damage': enemy_damage,
                        'vy': 5,
                        'vx': 0,
                        'is_enemy': True
                    })
            else:
                enemy_speed = max(1, int((base_enemy_speed - enemy_speed_reduction) + level * 0.2))
                if enemy_type == 'fast':
                    enemy_speed *= 2
                elif enemy_type == 'heavy':
                    enemy_speed = max(1, enemy_speed // 2)
                enemy['rect'].y += enemy_speed

            if enemy['rect'].colliderect(player_rect) and invincible_timer == 0 and not player_vanished:
                player_hp -= enemy_damage
                if enemy_type == 'exploder':
                    if sounds_loaded and "bomb" in implant_sounds and implant_sounds["bomb"]:
                        implant_sounds["bomb"].play()
                    explosion_damage = bullet_damage * 3
                    for e in enemies[:]:
                        if e != enemy:
                            dist = math.hypot(e['rect'].centerx - enemy['rect'].centerx,
                                              e['rect'].centery - enemy['rect'].centery)
                            if dist < 120:
                                e['hp'] -= explosion_damage
                                if e['hp'] <= 0:
                                    enemies.remove(e)
                                    score += 10 * (boss_number + 1)
                enemies.remove(enemy)
                invincible_timer = 60
                if player_hp <= 0:
                    state = STATE_GAME_OVER
                    menu_selection = 0
                    if not patches_earned:
                        last_earned_patches = level + score // 10
                        total_patches += last_earned_patches
                        patches_earned = True
                        if current_save_slot:
                            save_game(current_save_slot)
                    if sounds_loaded:
                        sound_death.play()
                continue

            if enemy['rect'].y > BASE_HEIGHT:
                enemies.remove(enemy)

        if state == STATE_GAME_OVER:
            continue

        # ---------- ПУЛИ ----------
        for bullet in bullets[:]:
            is_enemy = bullet.get('is_enemy', False)
            if is_enemy:
                bullet['rect'].y += bullet.get('vy', 5)
                if bullet['rect'].top > BASE_HEIGHT:
                    bullets.remove(bullet)
                    continue
                if bullet['rect'].colliderect(player_rect) and invincible_timer == 0 and not player_vanished:
                    player_hp -= bullet['damage']
                    bullets.remove(bullet)
                    invincible_timer = 60
                    if player_hp <= 0:
                        state = STATE_GAME_OVER
                        menu_selection = 0
                        if not patches_earned:
                            last_earned_patches = level + score // 10
                            total_patches += last_earned_patches
                            patches_earned = True
                            if current_save_slot:
                                save_game(current_save_slot)
                        if sounds_loaded:
                            sound_death.play()
                continue

            bullet['rect'].y -= bullet_speed
            if bullet['rect'].bottom < 0:
                bullets.remove(bullet)
                continue
            hit = False
            for enemy in enemies[:]:
                if bullet['rect'].colliderect(enemy['rect']):
                    enemy['hp'] -= bullet['damage']
                    bullets.remove(bullet)
                    hit = True
                    if enemy['hp'] <= 0:
                        if enemy.get('type') == 'exploder':
                            if sounds_loaded and "bomb" in implant_sounds and implant_sounds["bomb"]:
                                implant_sounds["bomb"].play()
                            explosion_damage = bullet_damage * 3
                            for e in enemies[:]:
                                if e != enemy:
                                    dist = math.hypot(e['rect'].centerx - enemy['rect'].centerx,
                                                      e['rect'].centery - enemy['rect'].centery)
                                    if dist < 120:
                                        e['hp'] -= explosion_damage
                                        if e['hp'] <= 0:
                                            enemies.remove(e)
                                            score += 10 * (boss_number + 1)
                        enemies.remove(enemy)
                        score += 10 * (boss_number + 1)
                    break
            if not hit and boss_active and boss is not None and bullet['rect'].colliderect(boss['rect']):
                boss['hp'] -= bullet['damage']
                bullets.remove(bullet)
                hit = True
                if boss['hp'] <= 0:
                    score += 500 * boss_number
                    level += 1
                    if boss_number > max_boss_defeated:
                        max_boss_defeated = boss_number
                        if current_save_slot:
                            save_game(current_save_slot)
                    boss = None
                    boss_active = False
                    level_timer = level_interval
                    if sounds_loaded:
                        sound_boss_win.play()
            if hit:
                continue

        # ---------- ПРЕДМЕТЫ ----------
        for item in items[:]:
            item.y += 4
            if item.colliderect(player_rect):
                items.remove(item)
                xp += 10 + xp_bonus
            elif item.y > BASE_HEIGHT:
                items.remove(item)

        # ---------- ЭФФЕКТЫ ВЗРЫВОВ ----------
        for exp in explosions[:]:
            exp['timer'] -= 1
            if exp['timer'] <= 0:
                explosions.remove(exp)

        # ---------- ПРОКАЧКА ----------
        if xp >= xp_to_next:
            if auto_upgrade:
                available = [uid for uid in generate_upgrade_choices() if uid in allowed_auto_upgrades]
                if available:
                    chosen = random.choice(available)
                    apply_upgrade(chosen)
                xp -= xp_to_next
                xp_to_next += 25
            else:
                if not upgrade_menu:
                    upgrade_menu = True
                    paused = True
                    menu_selection = 0
                    available = generate_upgrade_choices()
                    upgrade_choices = random.sample(available, min(3, len(available)))
                    if sounds_loaded:
                        sound_xp.play()

    # ================================================================
    # ОТРИСОВКА (без изменений)
    # ================================================================
    if state == STATE_PLAYING and not paused and random.randint(0, 150) == 0:
        canvas.fill((random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
    else:
        canvas.fill(BLACK)

    if state == STATE_SAVE_SELECT:
        draw_save_select()
    elif state == STATE_MENU:
        draw_main_menu()
    elif state == STATE_SETTINGS:
        draw_settings_menu()
    elif state == STATE_AUDIO_SETTINGS:
        draw_audio_settings()
    elif state == STATE_AUTOMATION_SETTINGS:
        draw_automation_settings()
    elif state == STATE_AUTO_UPGRADE_SETTINGS:
        draw_auto_upgrade_settings()
    elif state == STATE_AUTO_IMPLANT_SETTINGS:
        draw_auto_implant_settings()
    elif state == STATE_WORKSHOP:
        draw_workshop_menu()
    elif state == STATE_IMPLANTS:
        draw_implants_menu()
    elif state == STATE_CHECKPOINTS:
        draw_checkpoint_menu()
    elif state == STATE_PLAYING:
        player_color = ORANGE
        if implants["absolute"].get('duration_timer', 0) > 0:
            player_color = PURPLE
        if implants["vanish"].get('duration_timer', 0) > 0:
            alpha_surf = pygame.Surface((player_width, player_height), pygame.SRCALPHA)
            pygame.draw.rect(alpha_surf, (*player_color, 128), (0, 0, player_width, player_height))
            canvas.blit(alpha_surf, (player_x, player_y))
        else:
            if not (invincible_timer > 0 and invincible_timer % 6 < 3):
                pygame.draw.rect(canvas, player_color, (player_x, player_y, player_width, player_height))
                pygame.draw.circle(canvas, WHITE, (player_x + 15, player_y + 10), 5)
                pygame.draw.circle(canvas, WHITE, (player_x + 35, player_y + 10), 5)
                pygame.draw.circle(canvas, BLACK, (player_x + 15, player_y + 10), 2)
                pygame.draw.circle(canvas, BLACK, (player_x + 35, player_y + 10), 2)
                pygame.draw.rect(canvas, YELLOW, (player_x + player_width//2 - 4, player_y - 8, 8, 12))

        for enemy in enemies:
            r = enemy['rect']
            enemy_type = enemy.get('type', 'normal')
            if enemy_type == 'normal':
                color = RED
            elif enemy_type == 'fast':
                color = YELLOW
            elif enemy_type == 'heavy':
                color = PURPLE
            elif enemy_type == 'shooter':
                color = BLUE
            elif enemy_type == 'exploder':
                color = ORANGE_ENEMY
            else:
                color = RED
            pygame.draw.rect(canvas, color, r)
            if enemy_type == 'exploder':
                pygame.draw.line(canvas, BLACK, (r.x, r.y), (r.x + r.width, r.y + r.height), 2)
                pygame.draw.line(canvas, BLACK, (r.x + r.width, r.y), (r.x, r.y + r.height), 2)
            elif enemy_type == 'shooter':
                pygame.draw.line(canvas, BLACK, (r.x, r.y), (r.x + r.width, r.y + r.height), 2)
            elif enemy_type == 'heavy':
                pygame.draw.line(canvas, BLACK, (r.x, r.y), (r.x + r.width, r.y + r.height), 3)
                pygame.draw.line(canvas, BLACK, (r.x + r.width, r.y), (r.x, r.y + r.height), 3)
            if enemy['hp'] > 1:
                hp_text = font.render(str(enemy['hp']), True, WHITE)
                canvas.blit(hp_text, (r.x + 5, r.y + 5))

        if boss_active and boss is not None:
            r = boss['rect']
            color = RED if not boss.get('rush_active', False) else PURPLE
            if boss.get('state') == 'summoning':
                if boss.get('timer', 0) % 6 < 3:
                    color = RED
                else:
                    color = PURPLE
            pygame.draw.rect(canvas, color, r)
            pygame.draw.line(canvas, BLACK, (r.x, r.y), (r.x + r.width, r.y + r.height), 5)
            pygame.draw.line(canvas, BLACK, (r.x + r.width, r.y), (r.x, r.y + r.height), 5)
            hp_bar_width = r.width
            hp_bar_height = 8
            hp_ratio = boss['hp'] / boss['max_hp']
            pygame.draw.rect(canvas, RED, (r.x, r.y - hp_bar_height - 5, hp_bar_width, hp_bar_height))
            pygame.draw.rect(canvas, GREEN, (r.x, r.y - hp_bar_height - 5, hp_bar_width * hp_ratio, hp_bar_height))
            hp_text = small_font.render(f"HP: {boss['hp']}/{boss['max_hp']}", True, WHITE)
            canvas.blit(hp_text, (r.x, r.y - hp_bar_height - 25))

        for bullet in bullets:
            if bullet.get('is_enemy', False):
                pygame.draw.rect(canvas, BLUE, bullet['rect'])
            else:
                pygame.draw.rect(canvas, YELLOW, bullet['rect'])

        for item in items:
            pygame.draw.circle(canvas, GREEN, (item.x + 10, item.y + 10), 10)

        for bomb in bombs:
            pygame.draw.circle(canvas, RED, bomb['rect'].center, 8)

        for bullet in boss_bullets:
            pygame.draw.circle(canvas, PURPLE, bullet['rect'].center, 5)

        for exp in explosions:
            radius = 120 - (10 - exp['timer']) * 12
            if radius > 0:
                pygame.draw.circle(canvas, YELLOW, exp['pos'], int(radius), 2)

        # Отрисовка графических кнопок
        if btn_shoot:
            canvas.blit(btn_shoot, shoot_rect)
        if btn_crouch:
            canvas.blit(btn_crouch, crouch_rect)
        if btn_right:
            canvas.blit(btn_right, right_rect)
        if btn_left:
            canvas.blit(btn_left, left_rect)
        if btn_pause:
            canvas.blit(btn_pause, pause_rect)
        for key, img in implant_buttons.items():
            if img and implants[key]['owned']:
                canvas.blit(img, implant_rects[key])

        # Интерфейс
        score_text = font.render(f"Счёт: {score}  Уровень: {level}", True, WHITE)
        canvas.blit(score_text, (10, 10))

        hp_text = font.render(f"HP: {player_hp}/{player_max_hp}", True, RED)
        canvas.blit(hp_text, (10, 40))

        xp_bar_width = 200
        xp_bar_height = 15
        xp_bar_x = 10
        xp_bar_y = 70
        pygame.draw.rect(canvas, DARK_GRAY, (xp_bar_x, xp_bar_y, xp_bar_width, xp_bar_height))
        fill_width = min(xp_bar_width, int((xp / xp_to_next) * xp_bar_width))
        if fill_width > 0:
            pygame.draw.rect(canvas, GREEN, (xp_bar_x, xp_bar_y, fill_width, xp_bar_height))
        xp_text = font.render(f"XP: {xp}/{xp_to_next}", True, WHITE)
        canvas.blit(xp_text, (xp_bar_x + xp_bar_width + 10, xp_bar_y - 5))

        implants_y = 100
        for key, imp in implants.items():
            if imp['owned']:
                timer = imp.get('timer', 0)
                dur = imp.get('duration_timer', 0)
                if timer > 0:
                    status = f"Перезарядка: {timer//60:.1f}с"
                elif dur > 0:
                    status = f"Активно: {dur//60:.1f}с"
                else:
                    status = "Готово"
                imp_text = small_font.render(f"{imp['name']} ({key.upper()}): {status}", True, CYAN)
                canvas.blit(imp_text, (10, implants_y))
                implants_y += 25

        if paused and upgrade_menu:
            draw_upgrade_menu()
        elif paused and showing_stats:
            draw_stats_screen()
        elif paused:
            draw_pause_menu()

    elif state == STATE_GAME_OVER:
        if invincible_timer > 0 and invincible_timer % 6 < 3:
            pass
        else:
            pygame.draw.rect(canvas, ORANGE, (player_x, player_y, player_width, player_height))
            pygame.draw.circle(canvas, WHITE, (player_x + 15, player_y + 10), 5)
            pygame.draw.circle(canvas, WHITE, (player_x + 35, player_y + 10), 5)
            pygame.draw.circle(canvas, BLACK, (player_x + 15, player_y + 10), 2)
            pygame.draw.circle(canvas, BLACK, (player_x + 35, player_y + 10), 2)
            pygame.draw.rect(canvas, YELLOW, (player_x + player_width//2 - 4, player_y - 8, 8, 12))

        for enemy in enemies:
            r = enemy['rect']
            pygame.draw.rect(canvas, RED, r)
            pygame.draw.line(canvas, BLACK, (r.x, r.y), (r.x + 30, r.y + 30), 3)
            pygame.draw.line(canvas, BLACK, (r.x + 30, r.y), (r.x, r.y + 30), 3)
            if enemy['hp'] > 1:
                hp_text = font.render(str(enemy['hp']), True, WHITE)
                canvas.blit(hp_text, (r.x + 5, r.y + 5))

        for bullet in bullets:
            pygame.draw.rect(canvas, YELLOW, bullet['rect'])

        for item in items:
            pygame.draw.circle(canvas, GREEN, (item.x + 10, item.y + 10), 10)

        score_text = font.render(f"Счёт: {score}  Уровень: {level}", True, WHITE)
        canvas.blit(score_text, (10, 10))
        hp_text = font.render(f"HP: {player_hp}/{player_max_hp}", True, RED)
        canvas.blit(hp_text, (10, 40))

        draw_game_over_screen()

    if fullscreen:
        scaled_canvas = pygame.transform.scale(canvas, screen.get_size())
        screen.blit(scaled_canvas, (0, 0))
    else:
        screen.blit(canvas, (0, 0))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()